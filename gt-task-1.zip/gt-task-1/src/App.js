import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import NavBar from './components/NavBar';
import Home from './components/Home';
import Portfolio from './components/Portfolio';
import Services from './components/Services';
import About from './components/About';
import Team from './components/Team';
import HeroSection from './components/HeroSection';
import Footer from './components/Footer';
import Contact from './components/Contact';



function App() {
  return (
    <Router>
    <NavBar />
      <Switch>
        <Route exact path='/'>
          <HeroSection />
        </Route>
        <Route path='/services'>
          <Services />
        </Route>
        <Route path='/portfolio'>
          <Portfolio />
        </Route>
        <Route path='/about' >
          <About />
        </Route>
         <Route path='/team'>
          <Team />
        </Route>
        <Route path='/contact'>
          <Contact />
        </Route>
      </Switch>
      <Footer />
    </Router>
  )
}

export default App;
