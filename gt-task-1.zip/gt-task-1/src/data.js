export const data = [
    {
        id: 1,
        title: 'Threads',
        description: 'Illustration',
        img: 'https://startbootstrap.github.io/startbootstrap-agency/assets/img/portfolio/1.jpg',

    },

    {
        id: 2,
        title: 'Explore',
        description: 'Graphic Design',
        img: 'https://startbootstrap.github.io/startbootstrap-agency/assets/img/portfolio/2.jpg',

    },

    {
        id: 3,
        title: 'Finish',
        description: 'Identity',
        img: 'https://startbootstrap.github.io/startbootstrap-agency/assets/img/portfolio/3.jpg',

    },

    {
        id: 4,
        title: 'Lines',
        description: 'Branding',
        img: 'https://startbootstrap.github.io/startbootstrap-agency/assets/img/portfolio/4.jpg',

    },

    {
        id: 5,
        title: 'Southwest',
        description: 'Web Design',
        img: 'https://startbootstrap.github.io/startbootstrap-agency/assets/img/portfolio/5.jpg',

    },

    {
        id: 6,
        title: 'Window',
        description: 'Photograpgy',
        img: 'https://startbootstrap.github.io/startbootstrap-agency/assets/img/portfolio/6.jpg',

    }


];
