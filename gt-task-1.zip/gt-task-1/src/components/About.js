import React from 'react'

const About = () => {
    return (
        <section>
            <div className="services-header">
               <h1>About</h1>
               <p>Lorem ipsum dolor sit amet consectetur.</p>
            </div>
        </section>

    )
}

export default About
