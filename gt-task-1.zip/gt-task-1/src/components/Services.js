import React from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faShoppingCart } from '@fortawesome/free-solid-svg-icons'

const Services = () => {
    return (
        <section>
            <div className="services-header">
               <h1>SERVICES</h1>
               <p>Lorem ipsum dolor sit amet consectetur.</p>
            </div>
            <div className="service-item">
                <div>
                    <div>
                        <FontAwesomeIcon icon={faShoppingCart} style={{ fontSize: '70px' }} className="service-icon" />
                    </div>
                    <h3>E-Commerce</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima maxime quam architecto quo inventore harum ex magni, dicta impedit.</p>
                </div>
                <div>
                    <div>
                        <FontAwesomeIcon icon={faShoppingCart} style={{ fontSize: '70px' }} className="service-icon" />
                    </div>
                    <h3>E-Commerce</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima maxime quam architecto quo inventore harum ex magni, dicta impedit.</p>
                </div>
                <div>
                    <div>
                        <FontAwesomeIcon icon={faShoppingCart} style={{ fontSize: '70px' }} className="service-icon" />
                    </div>
                    <h3>E-Commerce</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima maxime quam architecto quo inventore harum ex magni, dicta impedit.</p>
                </div>
            </div>

        </section>

    )
}

export default Services
