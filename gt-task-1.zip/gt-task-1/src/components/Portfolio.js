import React, { useState } from 'react'
import { data } from '../data';


const Portfolio = () => {
    // const [portfolios, setPortfolios] = useState(data)
    const portfolios = data;

    return (
        <section className="pages-section">
            <div className="columns-title">
                <h1>PORTFOLIO</h1>
                <p>Lorem ipsum dolor sit amet consectetur.</p>
            </div>
            <div className="columns">
                {portfolios.map((portfolio) => {
                    const { title, description, img } = portfolio
                    return (
                        <div>
                            <img src={img} alt={title} style={{ marginRight: '20px',}} />
                            <div style={{ backgroundColor: '#fff', marginRight: '20px', padding: '20px'}}>
                                <h3> {title} </h3>
                                <p> {description} </p>
                            </div>
                        </div>
                    )
                })}
            </div >
        </section >

    )
}

export default Portfolio
