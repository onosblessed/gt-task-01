import React from 'react'

const Footer = () => {
    return (
        <section>
            <div className="footer-items">
               <p>Copyright © Your Website 2021.</p>
            </div>
        </section>
    )
}

export default Footer
