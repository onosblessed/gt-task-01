import React from 'react'

const HeroSection = () => {
    return (
        <div className="hero-section">
            <section>
                <div className="centered-text">
                    <div>
                        <h4 style={{ fontStyle: 'italic', fontSize: '2.5rem' }} >Welcome To Our Studio!</h4>
                        <h1 style={{ fontStyle: 'bold', fontSize: '4rem' }} >IT'S NICE TO MEET YOU</h1>
                    </div>
                    <div>
                        <button className="hero-button">TELL ME MORE</button>                   
                    </div>
                </div>
            </section>

        </div>
            
    )
}

export default HeroSection;
