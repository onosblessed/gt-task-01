import React from 'react'
import one from '../assets/img/team/one.jpg'
import two from '../assets/img/team/two.jpg'
import three from '../assets/img/team/three.jpg'

const Team = () => {
    return (
          <section className="team-background">
            <div className="section-title">
                <h2>OUR AMAZING TEAM</h2>
                <p className="team-description">Lorem ipsum dolor sit amet consectetur.</p>
            </div>

            <div className="team-images">
                <div className="staff-one">
                    <div className="staff-one-image">
                        <img className="round-image" src={one} width="300px" alt="staff" />
                    </div>

                    <div className="team-text-content">
                        <div className="staff-one-title">
                            <h4>Parveen Anand</h4>
                        </div>

                        <div className="staff-one-description">
                            <p style={{ color: '#6c757d' }}>Lead Designer</p>
                        </div>
                    </div>
                </div>

                 <div className="staff-one">
                    <div className="staff-one-image">
                        <img class="round-image" src={two} width="300px" alt="staff" />
                    </div>

                    <div className="team-text-content">
                        <div className="staff-one-title">
                            <h4>Parveen Anand</h4>
                        </div>

                        <div className="staff-one-description">
                            <p style={{ color: '#6c757d' }}>Lead Designer</p>
                        </div>
                    </div>
                </div>

                 <div className="staff-one">
                    <div className="staff-one-image">
                        <img class="round-image" src={three} width="300px" alt="staff" />
                    </div>

                    <div className="team-text-content">
                        <div className="staff-one-title">
                            <h4>Parveen Anand</h4>
                        </div>

                        <div className="staff-one-description">
                            <p style={{ color: '#6c757d' }}>Lead Designer</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    )
}

export default Team
