import React from 'react'
import { Link } from 'react-router-dom';

const NavBar = () => {
    return (
        <div style={{ position: 'sticky',
  top: '0' }}>
            <nav>
                <ul>
                    <li>
                        <Link to='/'>HOME</Link>
                    </li>
                    <li>
                        <Link to='/services'>SERVICES</Link>
                    </li>
                    <li>
                        <Link to='/portfolio'>PORTFOLIO</Link>
                    </li>
                    <li>
                        <Link to='/about'>ABOUT</Link>
                    </li>
                    <li>
                        <Link to='/team'>TEAM</Link>
                    </li>
                     <li>
                        <Link to='/contact'>CONTACT</Link>
                    </li>
                </ul>
            </nav>
        </div>
    )
}

export default NavBar

