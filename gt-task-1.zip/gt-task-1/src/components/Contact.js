import React from 'react'

const Contact = () => {
    return (
        <div>
            <div className="services-header">
                <h1>CONTACT US</h1>
                <p>Lorem ipsum dolor sit amet consectetur.</p>
            </div>
            <div>
                <form action="">

                </form>
            </div>
            
        </div>
    )
}

export default Contact
